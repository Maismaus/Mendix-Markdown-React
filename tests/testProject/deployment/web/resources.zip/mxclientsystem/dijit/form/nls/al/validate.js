//>>built
define("dijit/form/nls/al/validate",{invalidMessage:"Vlera e vendosur nuk është e saktë",missingMessage:"Kjo vlerë është e detyruar",rangeMessage:"Kjo vlerë është jashtë rradhe"});
