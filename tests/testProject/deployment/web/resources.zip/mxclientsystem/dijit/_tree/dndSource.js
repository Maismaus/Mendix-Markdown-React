//>>built
define("dijit/_tree/dndSource",["dojo/_base/kernel","dojo/_base/lang","../tree/dndSource"],function(_1,_2,_3){
_1.deprecated("dijit._tree.dndSource has been moved to dijit.tree.dndSource, use that instead","","2.0");
_2.setObject("dijit._tree.dndSource",_3);
});
