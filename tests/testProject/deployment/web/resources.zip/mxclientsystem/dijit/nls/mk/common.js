//>>built
define("dijit/nls/mk/common",{buttonOk:"OK",buttonCancel:"Откажи",buttonSave:"Зачувај",itemClose:"Затвори"});
